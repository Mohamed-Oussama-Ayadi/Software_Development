package tn.esprit.gestionzoo.entities;

public final class Penguin extends Aquatic{

    private float swimmingDepth;

    public Penguin(){}
    public Penguin(String family, String name, int age, boolean
            isMammal, String habitat, float swimmingDepth){
        super(family, name, age, isMammal, habitat);
        this.swimmingDepth = swimmingDepth;
    }

    public void swim(){
        System.out.println("This Penguin is swimming.");
    }

    @Override
    public String toString() {
        return "Penguin{" +
                "swimmingDepth=" + swimmingDepth +
                ", habitat='" + habitat + '\'' +
                ", family='" + family + '\'' +
                ", name='" + name + '\'' +
                ", age=" + age +
                ", isMammal=" + isMammal +
                "} " + super.toString();
    }
}
