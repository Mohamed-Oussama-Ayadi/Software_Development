package tn.esprit.gestionzoo.entities;

public sealed class Aquatic extends Animal permits Dolphin, Penguin{

    protected String habitat;

    public Aquatic(){}
    public Aquatic(String family, String name, int age, boolean
            isMammal, String habitat){
        super(family, name, age, isMammal);
        this.habitat = habitat;
    }

    public void swim(){
        System.out.println("This aquatic animal is swimming.");
    }

    @Override
    public String toString() {
        return "Aquatic{" +
                "habitat='" + habitat + '\'' +
                ", family='" + family + '\'' +
                ", name='" + name + '\'' +
                ", age=" + age +
                ", isMammal=" + isMammal +
                "} " + super.toString();
    }
}
