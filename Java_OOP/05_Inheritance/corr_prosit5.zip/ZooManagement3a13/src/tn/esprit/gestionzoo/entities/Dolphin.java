package tn.esprit.gestionzoo.entities;

public final class Dolphin extends Aquatic{

    private float swimmingSpeed;

    public Dolphin(){}
    public Dolphin(String family, String name, int age, boolean
            isMammal, String habitat, float swimmingSpeed){
        super(family, name, age, isMammal, habitat);
        this.swimmingSpeed = swimmingSpeed;
    }

    public void swim(){
        System.out.println("This dolphin is swimming.");
    }

    @Override
    public String toString() {
        return "Dolphin{" +
                "swimmingSpeed=" + swimmingSpeed +
                ", habitat='" + habitat + '\'' +
                ", family='" + family + '\'' +
                ", name='" + name + '\'' +
                ", age=" + age +
                ", isMammal=" + isMammal +
                "} " + super.toString();
    }
}
