package tn.esprit.gestionzoo.main;

import tn.esprit.gestionzoo.entities.*;

public class MainClass {

    public static void main(String[] args) {
        Animal a1 = new Animal("Lion","Simba",1,true);
        Zoo z1 = new Zoo("myZoo","Jerba");

        Aquatic aq1 = new Aquatic("Poisson","Dorade",1, false,"Mer");
        Terrestrial at1 = new Terrestrial("Lion","Simba",1,true,4);

        Penguin p1 = new Penguin("Penguin","Popo",1, false,"Pole Nord",12.4f);
        Dolphin d1 = new Dolphin("Dolphin","Dodo",1, true,"Mer Mediterainiere",25.9f);

        System.out.println(aq1);
        System.out.println(at1);
        System.out.println(p1);
        System.out.println(d1);

        aq1.swim();
        p1.swim();
        d1.swim();

    }
}
