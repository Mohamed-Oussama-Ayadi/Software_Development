package dep;

import java.util.*;

public class DepartementHashSet implements IDepartement<Departement>{

    private Set<Departement> departementSet = new HashSet<>();

    @Override
    public void ajouterDepartement(Departement departement) {
        departementSet.add(departement);
    }

    @Override
    public boolean rechercherDepartement(String nom) {
        for (Departement d : departementSet) {
            if (d.getNomDepartement().equals(nom))
                return true;
        }

//        Iterator<Departement> it = departementSet.iterator();
//        while (it.hasNext()){
//            if (it.next().getNomDepartement().equals(nom))
//                return true;
//        }

        return false;
    }

    @Override
    public boolean rechercherDepartement(Departement departement) {
        return departementSet.contains(departement);
    }

    @Override
    public void supprimerDepartement(Departement departement) {
        departementSet.remove(departement);
    }

    @Override
    public void displayDepartement() {
        System.out.println(departementSet);
    }

    @Override
    public TreeSet<Departement> trierDepartementById() {
        return new TreeSet<>(departementSet);
    }

    public TreeSet<Departement> trierDepartementByNom() {
        return new TreeSet<>(new Comparator<Departement>() {
            @Override
            public int compare(Departement o1, Departement o2) {
                return o1.getNomDepartement().compareTo(o2.getNomDepartement());
            }
        });
    }
}
