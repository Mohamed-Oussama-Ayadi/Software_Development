package dep;

import java.util.Objects;

public class Departement implements Comparable<Departement>{
    private int id;
    private String nomDepartement;
    private int nbrEmploye;

    public Departement() {}

    public Departement(int id, String nomDepartement, int nbrEmploye) {
        this.id = id;
        this.nomDepartement = nomDepartement;
        this.nbrEmploye = nbrEmploye;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNomDepartement() {
        return nomDepartement;
    }

    public void setNomDepartement(String nomDepartement) {
        this.nomDepartement = nomDepartement;
    }

    public int getNbrEmploye() {
        return nbrEmploye;
    }

    public void setNbrEmploye(int nbrEmploye) {
        this.nbrEmploye = nbrEmploye;
    }

    @Override
    public String toString() {
        return "dep.Departement{" +
                "id=" + id +
                ", nomDepartement='" + nomDepartement + '\'' +
                ", nbrEmploye=" + nbrEmploye +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Departement that)) return false;

        if (id != that.id) return false;
        return Objects.equals(nomDepartement, that.nomDepartement);
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result
                + (nomDepartement != null ? nomDepartement.hashCode() : 0);
        return result;
    }

    @Override
    public int compareTo(Departement o) {
        return Integer.compare(id, o.id);
    }
}
