package emp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class SocieteArrayList implements IGestion<Employee>{
    private List<Employee> employeeList = new ArrayList<>();

    @Override
    public void ajouterEmploye(Employee employee) {
        employeeList.add(employee);
    }

    @Override
    public boolean rechercherEmploye(String nom) {
        for (Employee e: employeeList) {
            if (e.getNom().equals(nom)) return true;
        }
        return false;
    }

    @Override
    public boolean rechercherEmploye(Employee employee) {
        return employeeList.contains(employee);
    }

    @Override
    public void supprimerEmploye(Employee employee) {
        employeeList.remove(employee);
    }

    @Override
    public void displayEmploye() {
        System.out.println(employeeList);
    }

    @Override
    public void trierEmployeParId() {
        Collections.sort(employeeList);
    }

    @Override
    public void trierEmployeParNomDépartementEtGrade() {
        Comparator<Employee> compNomDep = new Comparator<Employee>() {
            @Override
            public int compare(Employee o1, Employee o2) {
                return o1.getNomDepartement().compareTo(o2.getNomDepartement());
            }
        };

        Comparator<Employee> compGrade = new Comparator<Employee>() {
            @Override
            public int compare(Employee o1, Employee o2) {
                return Integer.compare(o1.getGrade(), o2.getGrade());
            }
        };

        Collections.sort(employeeList, compNomDep.thenComparing(compGrade));
    }
}
