import emp.Employee;
import emp.SocieteArrayList;

public class MainClass {

    public static void main(String[] args) {
        Employee e1 = new Employee(1,"Ben Salah", "Mariem", "IT", 5);
        Employee e2 = new Employee(9,"Ben Salah", "Mariem", "IT", 9);
        Employee e3 = new Employee(2,"Ben Salah", "Mourad", "Comm", 2);
        Employee e4 = new Employee(3,"Gharbi", "Wala", "HR", 10);

        e1.toString();
        SocieteArrayList sal = new SocieteArrayList();

        sal.ajouterEmploye(e1);
        sal.ajouterEmploye(e2);
        sal.ajouterEmploye(e3);
        sal.ajouterEmploye(e4);

        sal.displayEmploye();

        System.out.println(sal.rechercherEmploye("Gharbi2"));
        System.out.println(sal.rechercherEmploye(e2));

        sal.trierEmployeParId();

        sal.displayEmploye();

        sal.trierEmployeParNomDépartementEtGrade();

        sal.displayEmploye();
    }
}
