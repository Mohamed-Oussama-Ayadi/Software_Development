public class MainClass {

    public static void main(String[] args) {
        Animal a1 = new Animal("Lion","Simba",1,true);
        Zoo z1 = new Zoo("myZoo","Jerba",25);

        z1.displayZoo();
        System.out.println("++++++++++++++++++");
        z1.addAnimal(a1);
        System.out.println(z1);

    }
}
