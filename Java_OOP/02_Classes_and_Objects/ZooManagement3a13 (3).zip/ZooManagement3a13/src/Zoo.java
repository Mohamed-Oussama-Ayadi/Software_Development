public class Zoo {

    final int NBR_MAX_ANIMAL = 25;

    Animal[] animals;
    String name, city;
    int nbrCages;
    int nbrActualAnimal;

    public Zoo(){
        nbrActualAnimal=0;
        animals = new Animal[NBR_MAX_ANIMAL];
    }

    public Zoo(String name, String city,
               int nbrCages) {
        this.name = name;
        this.city = city;
        this.nbrCages = nbrCages;
        nbrActualAnimal = 0;
        animals = new Animal[nbrCages];
    }

    public void displayZoo(){
        System.out.println("Zoo name: "+name);
        System.out.println("Zoo city: "+city);
        System.out.println("Zoo number of cage: "+nbrCages);
    }

    public boolean addAnimal(Animal animal){
        if (searchAnimal(animal) != -1)
            return false;

        if (nbrActualAnimal < NBR_MAX_ANIMAL){
            animals[nbrActualAnimal++] = animal;
            return true;
        }

        return false;
    }

    public boolean removeAnimal(Animal animal){
        int indice = searchAnimal(animal);
        if (indice == -1)
            return false;

        animals[indice]=animals[--nbrActualAnimal];
        animals[nbrActualAnimal] = null;
        return false;
    }
    public int searchAnimal(Animal animal){
        for (int i = 0; i < nbrActualAnimal; i++) {
            if (animals[i].name.equals(animal.name))
                return i;
        }
        
        return -1;
    }

    public String toString() {
        String s = "Zoo name: "+name+" Zoo city: "+city+" Zoo number of actual animal: "+nbrActualAnimal+"\n";

        s+= "List Animals:\n";

        for (int i = 0; i < nbrActualAnimal; i++) {
            s+= animals[i].name +" "+animals[i].family+"\n";
        }

        return s;
    }
}
