package tn.esprit.gestionzoo.entities;

public class Zoo {
    private final int NBR_MAX_ANIMAL = 25;
    private Animal[] animals;
    private String name, city;
    private int nbrActualAnimal;

    public Zoo(){
        nbrActualAnimal=0;
        animals = new Animal[NBR_MAX_ANIMAL];
    }

    public Zoo(String name, String city) {
        this.name = name;
        this.city = city;
        nbrActualAnimal = 0;
        animals = new Animal[NBR_MAX_ANIMAL];
    }

    public void displayZoo(){
        System.out.println("tn.esprit.gestionzoo.entities.Zoo name: "+name);
        System.out.println("tn.esprit.gestionzoo.entities.Zoo city: "+city);
        System.out.println("tn.esprit.gestionzoo.entities.Zoo number of cage: "+nbrActualAnimal);
    }

    public boolean addAnimal(Animal animal){
        if (searchAnimal(animal) != -1)
            return false;

        if (!isZooFull()){
            animals[nbrActualAnimal++] = animal;
            return true;
        }

        return false;
    }

    public boolean removeAnimal(Animal animal){
        int indice = searchAnimal(animal);
        if (indice == -1)
            return false;

        animals[indice]=animals[--nbrActualAnimal];
        animals[nbrActualAnimal] = null;
        return false;
    }
    public int searchAnimal(Animal animal){
        for (int i = 0; i < nbrActualAnimal; i++) {
            if (animals[i].getName().equals(animal.getName()))
                return i;
        }
        
        return -1;
    }

    public boolean isZooFull(){
        return nbrActualAnimal == NBR_MAX_ANIMAL;
    }

    public String toString() {
        String s = "tn.esprit.gestionzoo.entities.Zoo name: "+name+" tn.esprit.gestionzoo.entities.Zoo city: "+city+" tn.esprit.gestionzoo.entities.Zoo number of actual animal: "+nbrActualAnimal+"\n";

        s+= "List Animals:\n";

        for (int i = 0; i < nbrActualAnimal; i++) {
            s+= animals[i].getName() +" "+animals[i].getFamily()+"\n";
        }

        return s;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name.isEmpty())
            System.out.println("Name must not be empty !");
        else
            this.name = name;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public int getNbrActualAnimal() {
        return nbrActualAnimal;
    }

    public Zoo comparerZoo(Zoo z1, Zoo z2){
        if(z1.nbrActualAnimal == z2.nbrActualAnimal) return null;
        
        return z1.nbrActualAnimal > z2.nbrActualAnimal ? z1 : z2;
    }
}
